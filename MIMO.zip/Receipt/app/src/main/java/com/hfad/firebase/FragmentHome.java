package com.hfad.firebase;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.functions.FirebaseFunctions;
import com.google.firebase.functions.HttpsCallableResult;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import androidx.core.content.FileProvider;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.os.Environment;
import android.provider.MediaStore;


import org.jetbrains.annotations.NotNull;

import static android.os.Looper.getMainLooper;

public class FragmentHome extends Fragment implements View.OnClickListener {
    private View view;

    private final int REQUEST_IMAGE_CAPTURE = 99;
    String currentPhotoPath = "";

    private LinearLayout fgHome;
    private TextView tvDate, tvBalance, tvViewAll;
    private CardView cvIncome, cvExpenses;
    private RecyclerView rvTransactions;

    private String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

    private FirebaseDatabase db = FirebaseDatabase.getInstance();
    private FirebaseStorage stor = FirebaseStorage.getInstance();
    private DatabaseReference refTrc = db.getReference().child("user").child(uid).child("transactions");
    private DatabaseReference refBalc = db.getReference().child("user").child(uid).child("balance");
    private DatabaseReference refCat = db.getReference().child("user").child(uid).child("categories");
    private StorageReference refPic = stor.getReference();

    private FirebaseFunctions mFunctions;

    private Date date;
    private SimpleDateFormat df = new SimpleDateFormat("dd MMM yyyy hh:mm a", Locale.getDefault());
    private Double balance = 0.0;
    private ArrayList<String> catIncome = new ArrayList<>();
    private ArrayList<String> catExpenses = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home, container, false);

        init();

        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                        dispatchTakePictureIntent();
                    }
        });


        return view;
    }

    @Override
    public void onClick(View v) {
        LayoutInflater inflater = LayoutInflater.from(getActivity());
        View view = inflater.inflate(R.layout.dialog_add_transaction, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(view);

        final TextView tvTitle = view.findViewById(R.id.tvTitle);
        final Spinner spCategory = view.findViewById(R.id.spCategory);
        final EditText etDescription = view.findViewById(R.id.etDescription);
        final EditText etAmount = view.findViewById(R.id.etAmount);
        etAmount.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(6, 2)});

        switch (v.getId()) {
            case R.id.cvIncome: {
                tvTitle.setText("Add New Income");

                ArrayAdapter<String> adapter =
                        new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, catIncome);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spCategory.setAdapter(adapter);

                builder.setCancelable(false)
                        .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogBox, int id) {

                            }
                        })
                        .setNegativeButton("Cancel",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialogBox, int id) {
                                        dialogBox.cancel();
                                    }
                                });

                final AlertDialog dialog = builder.create();
                dialog.show();
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(TextUtils.isEmpty(etAmount.getText().toString())) {
                            etAmount.setError("This field is mandatory");

                            return;
                        }

                        String key = refTrc.push().getKey();
                        String category = spCategory.getSelectedItem().toString();
                        String description = etDescription.getText().toString();
                        Double total = Double.parseDouble(etAmount.getText().toString());

                        Transaction trc = new Transaction(key, date, "Income", category, description, total);

                        refBalc.setValue(balance + total);

                        refTrc.child(key).setValue(trc).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                Toast.makeText(getActivity(), "Income successfully deleted", Toast.LENGTH_SHORT).show();

                                dialog.dismiss();
                            }
                        });
                    }
                });

                break;
            }
            case R.id.cvExpenses: {
                tvTitle.setText("Add New Expenses");

                ArrayAdapter<String> adapter =
                        new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, catExpenses);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spCategory.setAdapter(adapter);

                builder.setCancelable(false)
                        .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogBox, int id) {

                            }
                        })
                        .setNegativeButton("Cancel",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialogBox, int id) {
                                        dialogBox.cancel();
                                    }
                                });

                final AlertDialog dialog = builder.create();
                dialog.show();
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(TextUtils.isEmpty(etAmount.getText().toString())) {
                            etAmount.setError("This field is mandatory");

                            return;
                        }

                        String key = refTrc.push().getKey();
                        String category = spCategory.getSelectedItem().toString();
                        String description = etDescription.getText().toString();
                        Double total = Double.parseDouble(etAmount.getText().toString());

                        Transaction trc = new Transaction(key, date, "Expenses", category, description, total);

                        refBalc.setValue(balance - total);

                        refTrc.child(key).setValue(trc).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                Toast.makeText(getActivity(), "Expenses successfully created", Toast.LENGTH_SHORT).show();

                                dialog.dismiss();
                            }
                        });
                    }
                });

                break;
            }
            case R.id.tvViewAll: {
                Intent intent = new Intent(getActivity(), ActivityTransactionHistory.class);
                startActivity(intent);

                break;
            }
        }
    }

    private void init() {

        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Wallet Balance");
        fgHome = view.findViewById(R.id.fragment_home);
        tvDate = view.findViewById(R.id.tvDate);
        tvBalance = view.findViewById(R.id.tvBalance);
        cvIncome = view.findViewById(R.id.cvIncome);
        cvExpenses = view.findViewById(R.id.cvExpenses);
        rvTransactions = view.findViewById(R.id.rvTransactions);
        tvViewAll = view.findViewById(R.id.tvViewAll);

        cvIncome.setOnClickListener(this);
        cvExpenses.setOnClickListener(this);
        tvViewAll.setOnClickListener(this);

        //Get current time
        final Handler someHandler = new Handler(getMainLooper());
        someHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                date = Calendar.getInstance().getTime();
                String formattedDate = df.format(date);
                tvDate.setText(formattedDate);
                someHandler.postDelayed(this, 1000);
            }
        }, 10);

        //Get wallet balance
        refBalc.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!dataSnapshot.exists()) {
                    tvBalance.setText("RM 0.00");

                    return;
                }

                balance = dataSnapshot.getValue(Double.class);

                tvBalance.setText(String.format("RM %.2f", balance));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        //Get recent transactions
        refTrc.limitToLast(5).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!dataSnapshot.exists()) {
                    return;
                }

                final ArrayList<Transaction> listTrc = new ArrayList<>();

                for(DataSnapshot snaphot : dataSnapshot.getChildren()) {
                    Transaction trc = snaphot.getValue(Transaction.class);
                    listTrc.add(0, trc);
                }

                TransactionAdapter rvAdapter = new TransactionAdapter(getActivity(), listTrc);
                rvTransactions.setLayoutManager(new LinearLayoutManager(getActivity()));
                rvTransactions.setAdapter(rvAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        //Get Income category
        refCat.child("income").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ArrayList<String> list = new ArrayList<>();

                for(DataSnapshot snaphot : dataSnapshot.getChildren()) {
                    String category = snaphot.getValue(String.class);
                    list.add(category);
                }

                catIncome = list;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        //Get expenses category
        refCat.child("expenses").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ArrayList<String> list = new ArrayList<>();

                for(DataSnapshot snaphot : dataSnapshot.getChildren()) {
                    String category = snaphot.getValue(String.class);
                    list.add(category);
                }

                catExpenses = list;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
                Log.d("camera", "photoFile created");
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(getActivity(), "com.example.android.fileprovider",
                        photoFile);


                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == getActivity().RESULT_OK) {
            Bitmap imageBitmap = BitmapFactory.decodeFile(new File(currentPhotoPath).getAbsolutePath());
            //ivImage.setImageBitmap(imageBitmap);
            //refPic.push().imageBitMap;

            // get storage reference
            StorageReference receiptRef = refPic.child("receipt.jpg");
            StorageReference receiptImageRef = refPic.child("images/receipt.jpg");
            receiptRef.getName().equals(receiptImageRef.getName()); // true
            receiptRef.getPath().equals(receiptImageRef.getPath()); // false

            // get the data as bytes
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            imageBitmap = scaleBitmapDown(imageBitmap, 640);
            imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] imgData = baos.toByteArray();

            // convert bitmap to base64 encoded string
            String base64encoded = Base64.encodeToString(imgData, Base64.NO_WRAP);

            // initialze instance of Cloud Funcions
            mFunctions = FirebaseFunctions.getInstance();

            // Perform OCR
            // Create json request to cloud vision
            JsonObject request = new JsonObject();
            // Add image to request
            JsonObject image = new JsonObject();
            image.add("content", new JsonPrimitive(base64encoded));
            request.add("image", image);
            //Add features to the request
            JsonObject feature = new JsonObject();
            feature.add("type", new JsonPrimitive("DOCUMENT_TEXT_DETECTION"));
            JsonArray features = new JsonArray();
            features.add(feature);
            request.add("features", features);


            // language hints
            JsonObject imageContext = new JsonObject();
            JsonArray languageHints = new JsonArray();
            languageHints.add("en");
            imageContext.add("languageHints", languageHints);
            request.add("imageContext", imageContext);


            //invoke OCR function
            annotateImage(request.toString())
                    .addOnCompleteListener(new OnCompleteListener<JsonElement>() {
                        @Override
                        public void onComplete(@NonNull Task<JsonElement> task) {
                            if (!task.isSuccessful()) {
                                // Task failed with an exception
                                // ...
                                Context context = getActivity().getApplicationContext();
                                CharSequence text = "OCR fail";
                                int duration = Toast.LENGTH_SHORT;

                                Toast.makeText(context, text, duration).show();
                            } else {
                                Context context = getActivity().getApplicationContext();
                                CharSequence text = "Performing OCR...";
                                int duration = Toast.LENGTH_SHORT;
                                Toast.makeText(context, text, duration).show();

                                // extract text blocks from recognized text
                                // annotation
                                JsonObject annotation = task.getResult().getAsJsonArray().get(0).getAsJsonObject().get("fullTextAnnotation").getAsJsonObject();
                                text = "Analysing OCR results...";
                                Toast.makeText(context, text, duration).show();
                                System.out.format("%s%n", annotation.get("text").getAsString());
                                // analyze OCR result
                                ocrPostProcess(annotation);
                                }
                                /*
                                */
                            }
                    });

            // upload to firebase
            UploadTask uploadTask = receiptRef.putBytes(imgData);
            uploadTask.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull @NotNull Exception e) {
                    // TODO: handle unsuccessful uploads here
                }
            }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Uri downloadUrl = taskSnapshot.getUploadSessionUri();
                }
            });

            // create a reference with an initial file path and name
          //  StorageReference pathReference = refPic.child("images/receipt.jpg");

            // create a reference to a file from a Cloud Storage URI
           // StorageReference gsReference = stor.getReferenceFromUrl("gs://bucket/images/receipt.jph");

            // Create a reference from an HTTPS URL
          //  StorageReference httpsReference = stor.getReferenceFromUrl("https://firebasestorage.googleapis.com/b/bucket/o/images%20receipt.jpg")
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String imageFileName = "JPEG" + timeStamp + "_";
        File storageDir = getActivity().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName, ".jpg",storageDir );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }


    private Bitmap scaleBitmapDown(Bitmap bitmap, int maxDimension) {
        int originalWidth = bitmap.getWidth();
        int originalHeight = bitmap.getHeight();
        int resizedWidth = maxDimension;
        int resizedHeight = maxDimension;

        if (originalHeight > originalWidth) {
            resizedHeight = maxDimension;
            resizedWidth = (int) (resizedHeight * (float) originalWidth / (float) originalHeight);
        } else if (originalWidth > originalHeight) {
            resizedWidth = maxDimension;
            resizedHeight = (int) (resizedWidth * (float) originalHeight / (float) originalWidth);
        } else if (originalHeight == originalWidth) {
            resizedHeight = maxDimension;
            resizedWidth = maxDimension;
        }
        return Bitmap.createScaledBitmap(bitmap, resizedWidth, resizedHeight, false);
    }

    private Task<JsonElement> annotateImage(String requestJson) {
        return mFunctions
                .getHttpsCallable("annotateImage")
                .call(requestJson)
                .continueWith(new Continuation<HttpsCallableResult, JsonElement>() {
                    @Override
                    public JsonElement then(@NonNull Task<HttpsCallableResult> task) {
                        // This continuation runs on either success or failure, but if the task
                        // has failed then getResult() will throw an Exception which will be
                        // propagated down.
                        return JsonParser.parseString(new Gson().toJson(task.getResult().getData()));
                    }
                });
    }

    private void ocrPostProcess (JsonObject ocrResult) {
        for (JsonElement page : ocrResult.get("pages").getAsJsonArray()) {
            StringBuilder pageText = new StringBuilder();
            for (JsonElement block : page.getAsJsonObject().get("blocks").getAsJsonArray()) {
                StringBuilder blockText = new StringBuilder();
                for (JsonElement para : block.getAsJsonObject().get("paragraphs").getAsJsonArray()) {
                    StringBuilder paraText = new StringBuilder();
                    for (JsonElement word : para.getAsJsonObject().get("words").getAsJsonArray()) {
                        StringBuilder wordText = new StringBuilder();
                        for (JsonElement symbol : word.getAsJsonObject().get("symbols").getAsJsonArray()) {
                            wordText.append(symbol.getAsJsonObject().get("text").getAsString());
                            System.out.format("Symbol text: %s (confidence: %f)%n", symbol.getAsJsonObject().get("text").getAsString(), symbol.getAsJsonObject().get("confidence").getAsFloat());
                        }
                        System.out.format("Word text: %s (confidence: %f)%n%n", wordText.toString(), word.getAsJsonObject().get("confidence").getAsFloat());
                        System.out.format("Word bounding box: %s%n", word.getAsJsonObject().get("boundingBox"));
                        paraText.append(wordText.toString()).append(" ");
                    }
                    System.out.format("%nParagraph:%n%s%n", paraText);
                    System.out.format("Paragraph bounding box: %s%n", para.getAsJsonObject().get("boundingBox"));
                    System.out.format("Paragraph Confidence: %f%n", para.getAsJsonObject().get("confidence").getAsFloat());
                    blockText.append(paraText);
                }
                pageText.append(blockText);
            }
        }

    }



    class DecimalDigitsInputFilter implements InputFilter {
        private Pattern mPattern;
        DecimalDigitsInputFilter(int digitsBeforeZero, int digitsAfterZero) {
            mPattern = Pattern.compile("[0-9]{0," + (digitsBeforeZero - 1) + "}+((\\.[0-9]{0," + (digitsAfterZero - 1) + "})?)||(\\.)?");
        }
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            Matcher matcher = mPattern.matcher(dest);
            if (!matcher.matches()) {
                return "";
            }
            return null;
        }
    }


}