**Moved to https://github.com/firebase/user-data-protection/blob/main/doc/auto_rules_extraction.md**

