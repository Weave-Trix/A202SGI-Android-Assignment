# Community Samples

Check out these awesome samples built by the Firebase Community!

To add your own, use the following template:

```md
### [Emoji replacer](https://link-to-sample-source-code.com)

Use Cloud Functions to replace common words with emojis!

**Author:** @jhuleatt
```
